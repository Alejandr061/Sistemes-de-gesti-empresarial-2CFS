# -*- coding: utf-8 -*-

# Aqui indicamos que se cargaran los ficheros "biblioteca_comic.py" y "biblioteca_comic_categoria"
# Si creamos mas modelos, deben importarse en este fichero
from . import biblioteca_comic
from . import biblioteca_comic_categoria
