# -*- coding: utf-8 -*-
from odoo import models, fields

# 1. MODELO CICLO FORMATIVO (Ej: DAM, DAW)
class InstitutoCiclo(models.Model):
    _name = 'instituto.ciclo'
    _description = 'Ciclo Formativo'

    name = fields.Char(string="Nombre del Ciclo", required=True)
    descripcion = fields.Text(string="Descripción")
    
    # Relación: Un ciclo tiene muchos módulos
    modulo_ids = fields.One2many('instituto.modulo', 'ciclo_id', string="Módulos")


# 2. MODELO PROFESOR
class InstitutoProfessor(models.Model):
    _name = 'instituto.professor'
    _description = 'Profesor'

    name = fields.Char(string="Nombre", required=True)
    apellidos = fields.Char(string="Apellidos")
    dni = fields.Char(string="DNI")
    
    # Relación: Un profesor imparte muchos módulos
    modulo_ids = fields.One2many('instituto.modulo', 'professor_id', string="Módulos que imparte")


# 3. MODELO ALUMNO
class InstitutoAlumne(models.Model):
    _name = 'instituto.alumne'
    _description = 'Alumno'

    name = fields.Char(string="Nombre", required=True)
    apellidos = fields.Char(string="Apellidos")
    dni = fields.Char(string="DNI")
    
    # Relación: Un alumno se matricula en muchos módulos (Many2many)
    modulo_ids = fields.Many2many('instituto.modulo', string="Módulos Matriculados")


# 4. MODELO MÓDULO (ASIGNATURA)
class InstitutoModulo(models.Model):
    _name = 'instituto.modulo'
    _description = 'Módulo / Asignatura'

    name = fields.Char(string="Nombre del Módulo", required=True)
    horas = fields.Integer(string="Horas Lectivas")
    
    # Relaciones obligatorias según el PDF:
    # - Pertenece a un ciclo (Many2one)
    ciclo_id = fields.Many2one('instituto.ciclo', string="Ciclo Formativo", required=True)
    
    # - Lo imparte un profesor (Many2one)
    professor_id = fields.Many2one('instituto.professor', string="Profesor")
    
    # - Tiene alumnos matriculados (Many2many)
    alumne_ids = fields.Many2many('instituto.alumne', string="Alumnos Matriculados")