{
    'name': 'Gestión de Instituto',
    'summary': 'Módulo para gestionar ciclos, módulos, alumnos y profesores',
    'author': 'Tu Nombre',
    'version': '1.0',
    'depends': ['base'],
    'data': [
        'security/ir.model.access.csv',
        'views/instituto_views.xml',
    ],
    'installable': True,
    'application': True,
}