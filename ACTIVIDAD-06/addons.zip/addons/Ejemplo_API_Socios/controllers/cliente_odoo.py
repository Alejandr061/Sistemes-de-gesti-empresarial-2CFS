import xmlrpc.client

URL = 'http://localhost:8069'
DB = 'alehidsan'
USER = 'alejandro.hidsan2006@gmail.com'
PASS = 'iP78rL6J'

def conectar():
    """Autentica con Odoo mediante el servicio common."""
    try:
        common = xmlrpc.client.ServerProxy(f'{URL}/xmlrpc/2/common')
        uid = common.authenticate(DB, USER, PASS, {})
        if uid:
            return uid, xmlrpc.client.ServerProxy(f'{URL}/xmlrpc/2/object')
    except Exception as e:
        print(f"Error de connexió: {e}")
    return None, None

def ejecutar_orden(texto, uid, models):
    texto_limpio = texto.replace('"', '').replace('”', '').strip()
    partes = texto_limpio.split(',')
    
    ordre = partes[0].strip().capitalize()
    
    params = {}
    for p in partes[1:]:
        if '=' in p:
            k, v = p.split('=')
            params[k.strip().lower()] = v.strip()
    
    num_socio = params.get('num_socio')

    if ordre == "Crear":
        nombre = params.get('nombre')
        new_id = models.execute_kw(DB, uid, PASS, 'res.partner', 'create', [{
            'name': nombre,
            'ref': num_socio
        }])
        print(f"Resposta: Soci creat amb èxit en Odoo (ID: {new_id}).")

    elif ordre == "Consultar":
        socios = models.execute_kw(DB, uid, PASS, 'res.partner', 'search_read', 
                 [[['ref', '=', num_socio]]], {'fields': ['name', 'ref']})
        if socios:
            s = socios[0]
            print(f"Resposta: Dades d'Odoo -> Nom: {s['name']} | Referència: {s['ref']}")
        else:
            print("Resposta: Soci no trobat.")

    elif ordre == "Borrar":
        ids = models.execute_kw(DB, uid, PASS, 'res.partner', 'search', [[['ref', '=', num_socio]]])
        if ids:
            models.execute_kw(DB, uid, PASS, 'res.partner', 'unlink', [ids])
            print(f"Resposta: Soci {num_socio} eliminat correctament.")
        else:
            print("Resposta: El soci no existeix.")
    
    else:
        print("Resposta: Orden no soportada.")

if __name__ == '__main__':
    print("--- Iniciant el script de connexió ---")
    uid, models = conectar()
    
    if uid:
        print(f"Connectat a Odoo amb èxit! (UID d'usuari: {uid})")
        print("Escriu 'sortir' per a tancar el programa.")
        while True:
            entrada = input("\nOrdre > ")
            if entrada.lower() == 'sortir': 
                print("Tancant el client...")
                break
            ejecutar_orden(entrada, uid, models)
    else:
        print("Error: No s'ha pogut obtenir el UID.")
        print(f"Revisa que la base de dades '{DB}', l'usuari '{USER}' i el password siguin correctas.")