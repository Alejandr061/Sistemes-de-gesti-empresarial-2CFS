# -*- coding: utf-8 -*-
from datetime import timedelta
from odoo import models, fields, api
from odoo.exceptions import ValidationError

class LigaEquipo(models.Model):
    _name = 'liga.equipo'
    _description = 'Equipo de la liga'
    _order = 'nombre'
    _rec_name = 'nombre'

    nombre = fields.Char('Nombre equipo', required=True, index=True)
    escudo = fields.Image('Escudo equipo', max_width=50, max_height=50)
    fecha_fundacion = fields.Date('Fecha fundación')
    descripcion = fields.Html('Descripción', sanitize=True, strip_style=False)

    victorias = fields.Integer(default=0)
    empates = fields.Integer(default=0)
    derrotas = fields.Integer(default=0)

    jugados = fields.Integer(compute="_compute_jugados", store=True)

    @api.depends('victorias', 'empates', 'derrotas')
    def _compute_jugados(self):
        for record in self:
            record.jugados = record.victorias + record.empates + record.derrotas

    puntos = fields.Integer(default=0)
    
    goles_a_favor = fields.Integer()
    goles_en_contra = fields.Integer()

    _sql_constraints = [
        ('name_uniq', 'UNIQUE (nombre)', 'El nombre del equipo debe ser único.'),
    ]

    @api.constrains('fecha_fundacion')
    def _check_fecha_fundacion(self):
        for record in self:
            if record.fecha_fundacion and record.fecha_fundacion > fields.Date.today():
                raise ValidationError('La fecha de fundación del club debe ser anterior a hoy.')