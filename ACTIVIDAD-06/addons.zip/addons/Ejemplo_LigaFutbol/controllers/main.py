# -*- coding: utf-8 -*-
from odoo import http
from odoo.http import request
import json

# ============================
#  Controlador público HTTP
# ============================

class Main(http.Controller):

    # ------------------------------------------------------
    # Ruta 1: Devolver JSON (La que ya tenías)
    # ------------------------------------------------------
    @http.route('/ligafutbol/equipo/json', type='http', auth='none', csrf=False)
    def obtenerDatosEquiposJSON(self):
        equipos = request.env['liga.equipo'].sudo().search([])
        listaDatosEquipos = []

        for equipo in equipos:
            listaDatosEquipos.append([
                equipo.nombre,
                str(equipo.fecha_fundacion),
                equipo.jugados,
                equipo.puntos,
                equipo.victorias,
                equipo.empates,
                equipo.derrotas,
            ])

        json_result = json.dumps(listaDatosEquipos)
        return json_result

    # ------------------------------------------------------
    # Ruta 2: Eliminar Empates (¡LA NUEVA!)
    # ------------------------------------------------------
    @http.route('/eliminarempates', type='http', auth='public')
    def eliminar_empates(self, **kw):
        # Buscamos todos los partidos saltándonos los permisos de seguridad con sudo()
        partidos = request.env['liga.partido'].sudo().search([])
        
        # Filtramos solo los que tienen los mismos goles en casa que fuera
        empatados = partidos.filtered(lambda p: p.goles_casa == p.goles_fuera)
        num_eliminados = len(empatados)
        
        # Los eliminamos de la base de datos
        empatados.unlink()
        
        # Devolvemos el mensaje HTML al navegador
        return f"<h1>S'han eliminat {num_eliminados} partits empatats correctament.</h1>"